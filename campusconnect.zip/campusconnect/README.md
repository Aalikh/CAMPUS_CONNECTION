# CampusConnect prototype
```
pip install -r requirements.txt
streamlit run app.py
```
Sample data is created automatically on first run (delete campusconnect.db to reset).

Demo flow: sign in as a student -> Find & Book -> book Computer Lab 1 -> note the QR/code ->
sign in as another user and book the same slot (blocked, alternatives shown) -> Check-in with the code ->
sign in as Nishanth Kumar P (admin) -> Admin Dashboard.
